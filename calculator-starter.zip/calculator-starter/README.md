# Calculator starter

A Pen created on CodePen.io. Original URL: [https://codepen.io/zellwk/pen/pLgmGL](https://codepen.io/zellwk/pen/pLgmGL).

This is the starter file for a blog post "How to build a calculator". You can follow the lesson at https://zellwk.com/blog/calculator-part-1