fetch('https://www.el-tiempo.net/api/json/v2/provincias')
            .then(response => response.json())
            .then(data => {
                const weatherData = document.getElementById('weather-data');
                data.provincias.forEach(province => {
                    const card = document.createElement('div');
                    card.className = 'card';
                    card.innerHTML = `
                        <h2>${province.nombre}</h2>
                        <p>Temperatura: ${province.temperatura}°C</p>
                        <p>Humedad: ${province.humedad}%</p>
                        <p>Velocidad del viento: ${province.viento} m/s</p>`;
                    weatherData.appendChild(card);
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });